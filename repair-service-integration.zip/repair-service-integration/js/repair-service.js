document.addEventListener('DOMContentLoaded', function () {
    const container = document.getElementById('repair-service-container');

    fetch('https://your-web-app-url.com/api/orders')
        .then(response => response.json())
        .then(data => {
            let html = '<ul>';
            data.forEach(order => {
                html += `<li>Order ID: ${order.id} | Status: ${order.status}</li>`;
            });
            html += '</ul>';
            container.innerHTML = html;
        })
        .catch(error => console.error('Error fetching orders:', error));
});